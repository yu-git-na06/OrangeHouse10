<!-- footer -->
<footer class="footer">
    <div class="footer-inner common-wrapper">
        <div class="fotter-text">
            <p>◼︎住所：愛媛県西予市明浜町俵津3-155<br>
            ◼︎Tel：0894-89-4020<br>
            ◼︎E-mail：nicomaru.250@nicomaru.ne.jp<br>
            ◼︎営業時間：9:00-17:00</p>
        </div>
    </div>
    <div class="footer-copy">
        <p>©︎2024 Orange House10, All rights reserved.</p>
    </div>
</footer>
<!-- footer -->
<script src="<?=get_template_directory_uri(); ?>/script.js"></script>
<?php wp_footer(); ?>
</body>
</html>