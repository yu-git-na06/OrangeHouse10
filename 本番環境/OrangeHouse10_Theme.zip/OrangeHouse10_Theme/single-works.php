<?php get_header(); ?>
<h2><?php the_title(); ?></h2>
<p><?php the_content(); ?></p>
<?php get_footer(); ?>